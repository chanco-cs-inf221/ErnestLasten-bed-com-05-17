import React from "react"

function Booking(){
    return(
        <div className="book">
            <form action ="inner.html" method="post">
            <fieldset>
            <legend className="fill">Please fill the form below to book a room </legend>
            <label for="name">Username:  </label><input type="text" name="username" id="name" required autofocus placeholder="Your username" pattern="[a-zA-Z]{3,}" title="Please enter in more than four letters"/>
            <br></br>            <br></br>

            <label for="email">Email Address: </label><input type="text" name="email" id="email" required placeholder="Your Email" pattern="[a-zA-Z]{3,}@[a-zA-Z]{3,}[.]{1}[a-zA-Z]{2,}" title="Please enter a valid email address"/>
            <br></br>            <br></br>

            <label for="phone">Phone number:  </label><input type="tel" name="phone" id="phone" required placeholder="Please enter your phone number" pattern="[0-9]{4} [0-9]{3} [0-9]{3}" title="Please enter in a phone number in this format #### ### ### "/>
            <br></br>            <br></br>

            <label for="country">Select your country: (If you are from Africa, choose the specific country) </label><select name="country" id="country" required>
            
            <option value=""></option>
                    <option value="USA">USA</option>
                    <option value="UK">UK</option>
                    <option value="EUROPE-ELSEWHERE">EUROPE-ELSEWHERE</option>
                    <option value="SOUTH AMERICA">SOUTH AMERICA</option>
                    <option value="RUSSIA">RUSSIA</option>
                    <option value="MIDDLE EAST">MIDDLE EAST</option>
                    <option value="UNITED ARAB EMIRATES">UNITED ARAB EMIRATES</option>
                    <option value="ASIA-INDIA">ASIA-INDIA</option>
                    <option value="ASIA-CHINA">ASIA-CHINA</option>
                    <option value="ASIA-JAPAN">ASIA-JAPAN</option>
                    <option value="ASIA-KOREA">ASIA-KOREA</option>
                    <option value="AUSTRALIA">AUSTRALIA</option>
                    <option value="ASIA-ELSEWHERE">ASIA-ELSEWHERE</option>
                    <option value="MALAWI">MALAWI</option>
                    <option value="MOZAMBIQUE">MOZAMBIQUE</option>
                    <option value="SOUTH AFRICA">SOUTH AFRICA</option>
                    <option value="ZAMBIA">ZAMBIA</option>
                    <option value="TANZANIA">TANZANIA</option>
                    <option value="ZIMBABWE">ZIMBABWE</option>
                    <option value="ANGOLA">ANGOLA</option>
                    <option value="BOTSWANA">BOTSWANA</option>
                    <option value="NAMIBIA">NAMIBIA</option>
                    <option value="EGYPT">EGYPT</option>
                    <option value="TUNISIA">TUNISIA</option>
                    <option value="DRC">DRC</option>
                    <option value="NIGERIA">NIGERIA</option>
                    <option value="CAMEROON">CAMEROON</option>
                    <option value="IVORY COAST">IVORY COAST</option>
                    <option value="SIERRA LEONE">SIERRA LEON</option>
                    <option value="GHANA">GHANA</option>
                    <option value="ZAMBIA">ZAMBIA</option>
                    <option value="UGANDA">UGANDA</option>
                    <option value="TOGO">TOGO</option>
                    <option value="SWAZILAND">SWAZILAND</option>
                    <option value="SUDAN">SUDAN</option>
                    <option value="SOMALIA">SOMALIA</option>
                    <option value="RWANDA">RWANDA</option>
                    <option value="NIGER">NIGER</option>
                    <option value="MOROCCO">MOROCCO</option>
                    <option value="MALI">MALI</option>
                    <option value="KENYA">KENYA</option>
                    <option value="LESOTHO">LESOTHO</option>
                    <option value="BULUNDI">BULUNDI</option>
                    <option value="LIBYA">LIBYA</option>
                    <option value="CHAD">CHAD</option>
                    <option value="ETHIOPIA">ETHIOPIA</option>
                    <option value="GABON">GABON</option>
                    <option value="GAMBIA">GAMBIA</option>
                    <option value="GUINEA-BISSAU">GUINEA-BISSAU</option>
                    <option value="AFRICA - ELSEWHERE">AFRICA - ELSEWHERE</option>

                    <option value="ELSEWHERE">ELSEWHERE IN THE WORLD NOT LISTED</option>
                
            </select>
            </fieldset>
            </form>
        </div>
)
            
}
export default Booking