import React from "react"

function Rooms(){
    return(
        <div>
                <fieldset>
                <legend className="key">Choose a room from the list below then enter number of guests: </legend>
                <label for="date">Booking date: </label><input type="date" name="date" min="2019-02-04"></input>
                <br></br>

                <label for="rooms">Available rooms: (Please choose a room from the list below)</label>
                <select name="room" required>
                        <option value=""></option>
                        <option value="Room1">Room :01</option>   <option value="Room2">Room:02</option>
                        <option value="Room3">Room:03</option>   <option value="Room4">Room:04</option> 
                        <option value="Room5">Room:05</option>   <option value="Room6">Room:06</option> 
                        <option value="Room7">Room:07</option>   <option value="Room8">Room:08</option>
                        <option value="Room9">Room:09</option>   <option value="Room10">Room:10</option>  
                        <option value="Room11">Room:11</option>   <option value="Room12">Room:12</option> 
                        <option value="Room13">Room:13</option>   <option value="Room14">Room:14</option> 
                        <option value="Room15">Room:15</option>   <option value="Room16">Room:16</option> 
                        <option value="Room17">Room:17</option>   <option value="Room18">Room:18</option>           
                        <option value="Room19">Room:19</option>  <option value="Room20">Room-:20</option>                    
                </select>
                <br></br>                <br></br>                
                <label for="numberOfguests">Number of guests: </label><input type="number" name="numberOfGuest" min="1" max="9"></input>
                <br></br>                <br></br>   
                <input type="button" value="Submit" onClick="alert('You have successfully booked a room at Erne-Motel')"></input>
                <br></br><br></br>
                <input type="button" value="See manager's response" onClick="alert()"></input>

                </fieldset>
                
        </div>
)
}
export default Rooms