import React from "react";
import Navbar from "./Navbar";
import Header from "./Header";
import Booking from "./Booking"
import Rooms from "./Rooms"
import Footer from "./Footer"
import './Style.css';


//import { loadRooms, saveRooms } from './globals'




function MainComponent(){
    return(
        <div>
            <Navbar />
            <Header />
            <Booking />
            <Rooms />
            <Footer />
            
        </div>
    )
}

export default MainComponent;