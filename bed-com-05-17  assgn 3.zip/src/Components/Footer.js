import React from "react"

function Footer(){
    return(
        <footer className="foot">
        <strong>Erne Motel, copyright &copy; 2019</strong>
      </footer>
    )
}
export default Footer