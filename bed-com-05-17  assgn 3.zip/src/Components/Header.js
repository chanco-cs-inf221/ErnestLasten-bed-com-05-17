import React from "react"


function Header(){
    return(
        <div>
        <header className="head">
            <h1>WELCOME TO ERNIE MOTEL!</h1> 
            <br></br>
            <ul className="pic">
                <li>
                <img src="./motel.jpg" ></img>
                <img src="./boardroom.jpg"></img>
                <img src="./bed8.jpg"></img>           
                </li>
            </ul>
                       
            
            <br></br>
           


            
        </header>
       
        </div>
    )
}
       
export default Header 
        