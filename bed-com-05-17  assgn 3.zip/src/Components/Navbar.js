import React from "react"

function Navbar(){
    return (
        <div>
             <nav className="nav">             
                <ul className="ul">
                    <li><a href="bookingform.html" >Home</a> </li>
                    <li><a href="about.html" >About</a> </li>
                    <li><a href="services.html" >Services</a> </li>
                    <li><a href="contacts.html" >Contacts</a> </li>
                </ul>
            </nav>
        </div>
    );
}
export default Navbar